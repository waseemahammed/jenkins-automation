# General
default['jenkins-server']['admin']['username'] = 'admin'
default['jenkins-server']['admin']['password'] = 'jenkins_admin_password' # only used if the security strategy is "generate"
default['jenkins-server']['security']['strategy'] = 'generate' # generate or chef-vault
default['jenkins-server']['security']['chef-vault']['data_bag'] = 'jenkins-users'
default['jenkins-server']['security']['chef-vault']['data_bag_item'] = node['jenkins-server']['admin']['username']
default['jenkins-server']['security']['notifies']['resource'] = 'jenkins_script[configure permissions]'
default['jenkins']['security']['aws']['ssm_key'] = "arn:aws:kms:eu-west-1:455960343697:key/1c89931a-581c-4ac9-a3e7-4146902b8c55"
default['jenkins']['master']['private']['key'] = "jenkins-master-private-key"
default['jenkins']['master']['public']['key'] = "jenkins-master-public-key"


# Packages
default['jenkins-server']['java']['install'] = true
default['jenkins-server']['ant']['install'] = false
default['jenkins-server']['git']['install'] = true

# Settings
default['jenkins-server']['settings']['executors'] = node['cpu']['total'] < 2 ? 2 : node['cpu']['total']
default['jenkins-server']['settings']['slave_agent_port'] = 0 # Port | 0 to indicate random available TCP port | -1 to disable this service
default['jenkins-server']['settings']['global_properties']['env_vars'] = {
    'PATH' => "$PATH:/usr/local/bin:#{node['jenkins']['master']['home']}/.composer/vendor/bin",
}
default['jenkins-server']['settings']['system_email'] = 'tavisca_gce_devops@tavisca.com'
default['jenkins-server']['settings']['mailer']['smtp_host'] = 'email-smtp.eu-west-1.amazonaws.com'
default['jenkins-server']['settings']['mailer']['username'] = 'AKIAWUKK2WSIZCPA45CJ'
default['jenkins-server']['settings']['mailer']['password'] = 'hahhahahahhaahhaha'
default['jenkins-server']['settings']['mailer']['use_ssl'] = false
default['jenkins-server']['settings']['mailer']['smtp_port'] = '25'
default['jenkins-server']['settings']['mailer']['reply_to_address'] = 'tavisca_gce_devops@tavisca.com'
default['jenkins-server']['settings']['mailer']['charset'] = 'UTF-8'

# Node monitors
default['jenkins-server']['node_monitors']['architecture_monitor']['ignored'] = false
default['jenkins-server']['node_monitors']['clock_monitor']['ignored'] = false
default['jenkins-server']['node_monitors']['disk_space_monitor']['ignored'] = false
default['jenkins-server']['node_monitors']['disk_space_monitor']['free_space_threshold'] = '1GB'
default['jenkins-server']['node_monitors']['swap_space_monitor']['ignored'] = false
default['jenkins-server']['node_monitors']['temporary_space_monitor']['ignored'] = false
default['jenkins-server']['node_monitors']['temporary_space_monitor']['free_space_threshold'] = '1GB'
default['jenkins-server']['node_monitors']['response_time_monitor']['ignored'] = false

# Views
default['jenkins-server']['views'] = {}
default['jenkins-server']['purge_views'] = true

# Dev_mode attributes
default['jenkins-server']['dev_mode'] = false