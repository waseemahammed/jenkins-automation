#This will download the version provided as parameter here!!
default['jenkins']['upgrade']['version'] = '2.272' # LTS
default['jenkins']['upgrade']['mirror'] = 'https://updates.jenkins.io'
default['jenkins']['upgrade']['source'] = "#{node['jenkins']['upgrade']['mirror']}/"\
    'download/war/'\
    "#{node['jenkins']['upgrade']['version'] || node['jenkins']['upgrade']['channel']}/"\
    '/jenkins.war'

#default['jenkins']['master']['listen_address'] = '0.0.0.0'
#default['jenkins']['master']['jvm_options'] = '-Xms2g -Xmx6g -Djenkins.install.runSetupWizard=false -XX:+AlwaysPreTouch -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/var/lib/jenkins/heapdump/ -XX:+UseG1GC -XX:+UseStringDeduplication -XX:+ParallelRefProcEnabled -XX:+DisableExplicitGC -XX:+UnlockDiagnosticVMOptions -XX:+UnlockExperimentalVMOptions -verbose:gc -Xloggc:/var/log/jenkins/gc.log -XX:NumberOfGCLogFiles=2 -XX:+UseGCLogFileRotation -XX:GCLogFileSize=100m -XX:+PrintGC -XX:+PrintGCDateStamps -XX:+PrintGCDetails -XX:+PrintHeapAtGC -XX:+PrintGCCause -XX:+PrintTenuringDistribution -XX:+PrintReferenceGC -XX:+PrintAdaptiveSizePolicy -XX:ErrorFile=/var/log/jenkins/heapdump/hs_err_%p.log -XX:+IgnoreUnrecognizedVMOptions'