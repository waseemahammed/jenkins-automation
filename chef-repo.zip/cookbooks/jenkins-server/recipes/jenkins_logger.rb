#
# Cookbook:: jenkins-server
# Recipe:: jenkins_logger
# Author:: Waseem Ahammed <wahammed@tavisca.com>
# Copyright:: 2020, The Authors, All Rights Reserved.


ip_address = node['ipaddress']

puts "#{ip_address}"

template '/opt/aws/amazon-cloudwatch-agent/etc/cloudwatch-agent-config.json' do
        source 'cloudwatch-agent-config.json.erb'
        force_unlink true
	variables({
		ipaddress: "#{ip_address}"
	})
end

bash "restart cloudwatch agent service" do
	ignore_failure true
	code <<-EOH
	/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -m ec2 -a stop
	/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -afetch-config -m ec2 -c file://opt/aws/amazon-cloudwatch-agent/etc/cloudwatch-agent-config.json -s
	EOH
end

# Logrotate the JENKINS logs
#------------------------------------------------------------------------------------------------

cookbook_file '/etc/logrotate.d/jenkins_logrotate' do
    source 'jenkins_logrotate'
end