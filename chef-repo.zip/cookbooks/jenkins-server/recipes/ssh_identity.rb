# Generates a SSH identity file in the Jenkins home folder

# Install sshkey gem into chef
chef_gem 'sshkey'
require 'sshkey'

# Base location of ssh key
id_key_path = node['jenkins']['master']['home'] + '/.ssh/id_rsa'
authorized_keys_path = node['jenkins']['master']['home'] + '/.ssh/authorized_keys'
#id_key_comment = "#{node['jenkins']['master']['user']}@#{node['fqdn']}"

#Get Jenkins master public and private key from SSM
aws_ssm_parameter_store 'get jenkins master private key' do
    path "#{node['jenkins']['master']['private']['key']}"
    return_key 'jenkins-master-private-key'
    with_decryption true
    type 'SecureString'
    key_id "#{node['jenkins']['security']['aws']['ssm_key']}"
    action :nothing
end.run_action :get

aws_ssm_parameter_store 'get jenkins master public key' do
    path "#{node['jenkins']['master']['public']['key']}"
    return_key 'jenkins-master-public-key'
    with_decryption true
    type 'SecureString'
    key_id "#{node['jenkins']['security']['aws']['ssm_key']}"
    action :nothing
end.run_action :get

# Create ~/.ssh directory
directory "#{node['jenkins']['master']['home']}/.ssh" do
  owner node['jenkins']['master']['user']
  group node['jenkins']['master']['group']
  mode '0700'
end

# Store private key on disk
file id_key_path do
  content node.run_state['jenkins-master-private-key']
  owner node['jenkins']['master']['user']
  group node['jenkins']['master']['group']
  mode '0600'
  action :create_if_missing
end

# Store public key on disk
file "#{id_key_path}.pub" do
content node.run_state['jenkins-master-public-key']
  owner node['jenkins']['master']['user']
  group node['jenkins']['master']['group']
  mode '0644'
  action :create_if_missing
end

file "#{authorized_keys_path}.pub" do
content node.run_state['jenkins-master-public-key']
  owner node['jenkins']['master']['user']
  group node['jenkins']['master']['group']
  mode '0644'
  action :create_if_missing
end