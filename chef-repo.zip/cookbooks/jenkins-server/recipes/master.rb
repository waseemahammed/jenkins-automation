include_recipe 'jenkins::master'
include_recipe 'jenkins-server::user'
include_recipe 'jenkins-server::ssh_identity'