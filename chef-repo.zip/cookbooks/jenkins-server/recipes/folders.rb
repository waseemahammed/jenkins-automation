jenkins_script 'add_folder' do
  command <<-EOH.gsub(/^ {4}/, '')
    import com.cloudbees.hudson.plugins.folder.*
    import org.jenkinsci.plugins.workflow.*
    import jenkins.model.*

    Jenkins jenkins = Jenkins.instance // saves some typing

    // Bring some values in from ansible using the jenkins_script modules wierd "args" approach (these are not gstrings)
    String folderName = "myfolder"
    String folderNameTemp = folderName + "-folder"

    def folder = jenkins.getItem(folderName)
    if (folder == null) {
    // Create the folder if it doesn't exist or if no existing job has the same name
    folder = jenkins.createProject(Folder.class, folderName)
    } else {
    if (folder.getClass() != Folder.class) {
        // when folderName exists, but is not a folder we make the folder with a temp name
        folder = jenkins.createProject(Folder.class, folderNameTemp)
        // Move existing jobs from the same environment to folders (preseve history)
        //Item[] items = jenkins.getItems(WorkflowJob.class)
        //def job_regex = "^" + folderName

        //items.grep { it.name =~ job_regex }.each { job ->
        //Items.move(job, folder)
        //}

        // Rename the temp folder now we've moved the jobs
        folder.renameTo(folderName)
      }
    }
  EOH
end
