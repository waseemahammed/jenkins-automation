include_recipe 'jenkins::master'

#Get jenkins.yaml file for Casc and Copy to casc location
bash 'Create casc properties directory location' do
  code <<-EOH
  mkdir -p /var/lib/jenkins/casc_configs
  chown jenkins:jenkins /var/lib/jenkins/casc_configs
  EOH
end

# #Copy jenkins.yaml file for casc
cookbook_file "/var/lib/jenkins/casc_configs/jenkins.yaml" do
  source "jenkins.yaml"
  owner 'jenkins'
  group 'jenkins'
end

# Install casc plugin
jenkins_plugins = %w(
  configuration-as-code
  configuration-as-code-groovy
  configuration-as-code-secret-ssm
)

jenkins_plugins.each do |plugin|
  jenkins_plugin plugin do
    #notifies :execute, 'jenkins_command[restart]', :immediately
  end
end

jenkins_command 'restart' do
  action :execute
end