if node['jenkins-server']['java']['install']
  #include_recipe 'java'
  openjdk_pkg_install '8' do
  end
end

if node['jenkins-server']['git']['install']
  include_recipe 'git'
end

# Add IpTable rules
bash "Add IPTABLE rules" do
	code <<-EOH
	sudo iptables -I INPUT 1 -p tcp --dport 8080 -j ACCEPT 
	sudo service iptables save
	EOH
end

#Create swap for Jenkins server
swap_file '/swapfile' do
  size 1024
  persist true
end

include_recipe 'jenkins-server::master'
include_recipe 'jenkins-server::install_plugins'
include_recipe 'jenkins-server::casc'
include_recipe 'jenkins-server::settings'
include_recipe 'jenkins-server::security'
include_recipe 'jenkins-server::jenkins_logger'