#Backup existing Jenkins war file
bash "Backup existing Jenkins war file" do
	code <<-EOH
	  mv /usr/lib/jenkins/jenkins.war  /usr/lib/jenkins/jenkins.war.bkp
	EOH
end

#Download latest version
bash "Download latest version" do
  code <<-EOH
    cd /usr/lib/jenkins/
    wget #{node['jenkins']['upgrade']['source']}
    chmod 0644 /usr/lib/jenkins/jenkins.war
	EOH
end

#Restart Jenkins
bash "Restart Jenkins" do
  code <<-EOH
    service jenkins restart
	EOH
end