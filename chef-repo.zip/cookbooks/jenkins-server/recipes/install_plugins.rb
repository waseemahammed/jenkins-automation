# Ensure jenkins user home dir exists
directory "/var/lib/jenkins" do
  owner "jenkins"
  group "jenkins"
  action :create
end

# Fixes possible error:
#   STDOUT: `git` is neither a valid file, URL, nor a plugin artifact name in the update center
#   No update center data is retrieved yet from: http://updates.jenkins-ci.org/update-center.json
directory "/var/lib/jenkins/updates" do
  owner "jenkins"
  group "jenkins"
  action :create
end

execute "update jenkins update center" do
  command "wget http://updates.jenkins-ci.org/update-center.json -qO- | sed '1d;$d'  > /var/lib/jenkins/updates/default.json"
  user "jenkins"
  group "jenkins"
  creates "/var/lib/jenkins/updates/default.json"
end

# Install all plugins and restart once
#jenkins_cli "install-plugin #{plugins_to_install.join(' ')}"
#jenkins_cli "safe-restart"

jenkins_plugins = %w(
  mailer
  ssh-slaves
  jdk-tool
  display-url-api
  credentials
  matrix-auth
  authorize-project
  sonar
  copyartifact
  timestamper
  m2release
  build-monitor-plugin
  bitbucket
  rebuild
  slack
  github
  workflow-aggregator
  quality-gates
  nexus-jenkins-plugin
  extensible-choice-parameter
  docker-plugin
  veracode-scan
  allure-jenkins-plugin
  role-strategy
  cloudbees-folder
  workflow-cps-global-lib
  email-ext
  snakeyaml-api
  active-directory
  openJDK-native-plugin
  gradle
  nodejs
  git-parameter
  JDK_Parameter_Plugin
  adoptopenjdk
  blueocean
  build-timestamp
  custom-tools-plugin
  ansible
  terraform
  build-user-vars-plugin
  kubernetes-cd
  audit-trail
  monitoring
  jqs-monitoring
  envinject
  github-autostatus
  s3
  pipeline-aws
  amazon-ecr
  console-tail
  disk-usage
  simple-theme-plugin
  saml
  atlassian-jira-software-cloud
  Office-365-Connector
  favorite
  ws-cleanup
  docker-workflow
)

jenkins_plugins.each do |plugin|
  jenkins_plugin plugin do
    #notifies :execute, 'jenkins_command[safe-restart]', :immediately
  end
end

jenkins_command 'safe-restart' do
  action :execute
end