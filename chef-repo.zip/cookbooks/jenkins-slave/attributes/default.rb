# General

default['jenkins-server']['java']['install'] = true
default['jenkins-server']['git']['install'] = true

default['jenkins']['security']['aws']['ssm_key'] = "arn:aws:kms:eu-west-1:455960343697:key/1c89931a-581c-4ac9-a3e7-4146902b8c55"
default['jenkins']['slave']['aws']['dev_config'] = "dev-gce-nextgen-eks-config"
default['jenkins']['slave']['aws']['qa_config'] = "qa-gce-nextgen-eks-config"
default['jenkins']['slave']['aws']['stage_config'] = "stage-gce-nextgen-eks-config"
default['jenkins']['slave']['aws']['prod_config'] = "prod-gce-nextgen-eks-config"

default['jenkins']['slave']['private']['key'] = "jenkins-slave-private-key"
default['jenkins']['slave']['public']['key'] = "jenkins-slave-public-key"
default['jenkins']['slave']['home'] = "/var/lib/jenkins"
default['jenkins']['slave']['user'] = "jenkins"
default['jenkins']['slave']['group'] = "jenkins"