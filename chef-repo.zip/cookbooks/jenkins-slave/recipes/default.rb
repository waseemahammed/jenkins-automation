#Install Java
if node['jenkins-server']['java']['install']
    openjdk_pkg_install '8' do
    end
end

include_recipe 'jenkins-slave::user'
include_recipe 'jenkins-slave::ssh_identity'
include_recipe 'jenkins-slave::node_config'
include_recipe 'jenkins-slave::install_docker'
include_recipe 'jenkins-slave::install_kube_essentials'