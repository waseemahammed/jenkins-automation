# Add IpTable rules for slave to run docker API
bash "Add IPTABLE rules" do
	code <<-EOH
	sudo iptables -I INPUT 1 -p tcp --dport 4243 -j ACCEPT 
	sudo service iptables save
	EOH
end

#Install Docker
bash 'Install Docker' do
    code <<-EOH
        sudo amazon-linux-extras install docker -y
        sudo service docker start
        sudo usermod -a -G docker jenkins
    EOH
end

#Make docker auto-start
bash 'Make docker auto-start' do
    code <<-EOH
        sudo chkconfig docker on
    EOH
end

#Configure Docker API access
cookbook_file "/usr/lib/systemd/system/docker.service" do
    source "docker.service"
end

#Reload and restart docker service
bash 'Reload and restart docker service' do
    code <<-EOH
        sudo systemctl daemon-reload
        sudo service docker restart
    EOH
end



