# Generates a SSH identity file in the Jenkins home folder

# Install sshkey gem into chef
chef_gem 'sshkey'
require 'sshkey'

# Base location of ssh key
id_key_path = node['jenkins']['slave']['home'] + '/.ssh/id_rsa'
authorized_keys_path = node['jenkins']['slave']['home'] + '/.ssh/authorized_keys'
#id_key_comment = "#{node['jenkins']['master']['user']}@#{node['fqdn']}"


#Get Jenkins Slave public and private key from SSM
aws_ssm_parameter_store 'get jenkins slave private key' do
    path "#{node['jenkins']['slave']['private']['key']}"
    return_key 'jenkins-slave-private-key'
    with_decryption true
    type 'SecureString'
    key_id "#{node['jenkins']['security']['aws']['ssm_key']}"
    action :nothing
end.run_action :get

aws_ssm_parameter_store 'get jenkins slave public key' do
    path "#{node['jenkins']['slave']['public']['key']}"
    return_key 'jenkins-slave-public-key'
    with_decryption true
    type 'SecureString'
    key_id "#{node['jenkins']['security']['aws']['ssm_key']}"
    action :nothing
end.run_action :get

# Create ~/.ssh directory
directory "#{node['jenkins']['slave']['home']}/.ssh" do
  owner node['jenkins']['slave']['user']
  group node['jenkins']['slave']['group']
  mode '0700'
end

# Store private key on disk
file id_key_path do
  content node.run_state['jenkins-slave-private-key']
  owner node['jenkins']['slave']['user']
  group node['jenkins']['slave']['group']
  mode '0600'
  action :create_if_missing
end

# Store public key on disk
file "#{id_key_path}" do
  content node.run_state['jenkins-slave-public-key']
  owner node['jenkins']['slave']['user']
  group node['jenkins']['slave']['group']
  mode '0600'
  action :create_if_missing
end

file "#{authorized_keys_path}" do
  content node.run_state['jenkins-slave-public-key']
  owner node['jenkins']['slave']['user']
  group node['jenkins']['slave']['group']
  mode '0600'
  action :create_if_missing
end

service 'reload sshd' do
  service_name 'sshd'
  action :restart
end
