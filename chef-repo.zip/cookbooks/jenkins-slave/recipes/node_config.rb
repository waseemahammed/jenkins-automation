#Install Ansible
bash 'install ansible' do
    code <<-EOH
      sudo amazon-linux-extras install ansible2 -y
    EOH
end

#Install Packer
bash 'install packer' do
    code <<-EOH
      sudo yum install -y yum-utils
      sudo yum-config-manager --add-repo https://rpm.releases.hashicorp.com/AmazonLinux/hashicorp.repo
      sudo yum -y install packer -y
    EOH
end

#Install git
if node['jenkins-server']['git']['install']
  include_recipe 'git'
end