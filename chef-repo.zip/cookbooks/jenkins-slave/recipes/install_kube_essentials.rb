# Install helm3
bash "Install helm3" do
    code <<-EOH
        cd /home/ec2-user/
        wget https://get.helm.sh/helm-v3.3.4-linux-amd64.tar.gz
        tar -zxvf helm-v3.3.4-linux-amd64.tar.gz
        mv linux-amd64/helm /usr/bin/helm
        rm -rf /home/ec2-user/linux-amd64 helm-v3.3.4-linux-amd64.tar.gz
        EOH
end

# Install helm s3 plugin
bash "Install helm s3 plugin" do
  code <<-EOH
    su - jenkins -c 'helm plugin install https://github.com/hypnoglow/helm-s3.git'
  EOH
end

#Install kubectl
bash "Install kubectl" do
    code <<-EOH
        cd /home/ec2-user/
        curl -LOsS "https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl"
        chmod +x ./kubectl
        sudo mv ./kubectl /usr/bin/kubectl
        EOH
end

#create .kube directory
bash "create .kube directory" do
  code <<-EOH
        mkdir -p /var/lib/jenkins/.kube/adminconf
  EOH
end

#Copy kube configs from SSM Parameter store
aws_ssm_parameter_store 'get dev config' do
    path "#{node['jenkins']['slave']['aws']['dev_config']}"
    return_key 'dev-gce-nextgen-eks-config'
    with_decryption true
    type 'SecureString'
    key_id "#{node['jenkins']['security']['aws']['ssm_key']}"
    action :nothing
  end.run_action :get

file "/var/lib/jenkins/.kube/adminconf/#{node['jenkins']['slave']['aws']['dev_config']}.yaml" do
    content node.run_state['dev-gce-nextgen-eks-config']
    action :create_if_missing
end

#Copy kube configs from SSM Parameter store
aws_ssm_parameter_store 'get QA config' do
    path "#{node['jenkins']['slave']['aws']['qa_config']}"
    return_key 'qa-gce-nextgen-eks-config'
    with_decryption true
    type 'SecureString'
    key_id "#{node['jenkins']['security']['aws']['ssm_key']}"
    action :nothing
  end.run_action :get

file "/var/lib/jenkins/.kube/adminconf/#{node['jenkins']['slave']['aws']['qa_config']}.yaml" do
    content node.run_state['qa-gce-nextgen-eks-config']
    action :create_if_missing
end

#Copy kube configs from SSM Parameter store
aws_ssm_parameter_store 'get Stage config' do
    path "#{node['jenkins']['slave']['aws']['stage_config']}"
    return_key 'stage-gce-nextgen-eks-config'
    with_decryption true
    type 'SecureString'
    key_id "#{node['jenkins']['security']['aws']['ssm_key']}"
    action :nothing
  end.run_action :get

file "/var/lib/jenkins/.kube/adminconf/#{node['jenkins']['slave']['aws']['stage_config']}.yaml" do
    content node.run_state['stage-gce-nextgen-eks-config']
    action :create_if_missing
end

#Copy kube configs from SSM Parameter store
aws_ssm_parameter_store 'get prod config' do
    path "#{node['jenkins']['slave']['aws']['prod_config']}"
    return_key 'prod-gce-nextgen-eks-config'
    with_decryption true
    type 'SecureString'
    key_id "#{node['jenkins']['security']['aws']['ssm_key']}"
    action :nothing
  end.run_action :get

file "/var/lib/jenkins/.kube/adminconf/#{node['jenkins']['slave']['aws']['prod_config']}.yaml" do
    content node.run_state['prod-gce-nextgen-eks-config']
    action :create_if_missing
end