node.override['jenkins']['slave']['home'] = "/var/lib/jenkins"

# Adds a shell to the Jenkins system user with home folder files
user node['jenkins']['slave']['user'] do
  shell '/bin/bash'
  home node['jenkins']['slave']['home']
  manage_home true
end

# Copy home folder skeleton files from /etc/skel, because the Jenkins package install
# that creates the Jenkins user with a home directory doesn't do this.
bash 'copy_home_folder_skeleton_files' do
  cwd ::File.dirname(node['jenkins']['slave']['home'])
  code <<-EOH
    cp -r /etc/skel/. #{node['jenkins']['slave']['home']}
    chown #{node['jenkins']['slave']['user']}:#{node['jenkins']['slave']['group']} #{node['jenkins']['slave']['home']}/.bash*
  EOH
  not_if { ::File.exist?("#{node['jenkins']['slave']['home']}/.bashrc") }
end

#Configure sshd
cookbook_file "/etc/ssh/sshd_config" do
  source "sshd_config"
  action :create
end

# execute "Do some sed" do
#   command "sed 's/AllowUsers ec2-user/AllowUsers ec2-user jenkins/g' /etc/ssh/sshd_config"
#   action :run
# end

#turn OFF password expiration and aging
bash 'turn OFF password expiration and aging' do
  code <<-EOH
    sudo chage -I -1 -m 0 -M 99999 -E -1 jenkins
  EOH
end

cookbook_file "/etc/sudoers.d/jenkins-users" do
  source "jenkins-users"
  action :create_if_missing
end
