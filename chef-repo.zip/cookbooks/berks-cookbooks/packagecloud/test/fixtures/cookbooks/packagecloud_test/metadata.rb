name 'packagecloud_test'

depends 'yum'
depends 'packagecloud'
