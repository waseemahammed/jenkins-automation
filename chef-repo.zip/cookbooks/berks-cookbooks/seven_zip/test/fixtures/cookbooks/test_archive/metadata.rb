name    'test_archive'
version '1.0.0'
depends 'seven_zip'
