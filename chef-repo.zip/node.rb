{
"run_list": ["recipe[jenkins-server]"]
}
