{
"run_list": ["recipe[jenkins-slave]"]
}
